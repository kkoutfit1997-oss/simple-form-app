import React,{useEffect,useState} from "react";
import {createRoot} from "react-dom/client";
import {Amplify} from "aws-amplify";
import {generateClient} from "aws-amplify/data";
import {Authenticator,useAuthenticator} from "@aws-amplify/ui-react";
import outputs from "../amplify_outputs.json";
import "@aws-amplify/ui-react/styles.css";
import "./style.css";

Amplify.configure(outputs);
const client=generateClient();

function FormPage(){
 const [a,setA]=useState(""),[b,setB]=useState(""),[msg,setMsg]=useState(""),[busy,setBusy]=useState(false);
 async function submit(e){
  e.preventDefault();
  if(!a.trim()||!b.trim())return setMsg("2つとも入力してください。");
  setBusy(true);setMsg("送信中…");
  const {errors}=await client.models.Submission.create({field1:a.trim(),field2:b.trim()});
  setBusy(false);
  if(errors?.length)setMsg("送信に失敗しました。");
  else{setA("");setB("");setMsg("送信しました。");}
 }
 return <main className="page"><div className="brand">Form</div>
  <section className="hero"><p className="eyebrow">SIMPLE FORM</p><h1>情報を入力してください。</h1>
  <p className="lead">必要な情報を入力して送信してください。</p></section>
  <form className="card" onSubmit={submit}>
   {/* ★ 表示名・placeholderはここを変更できます */}
   <label><span>入力欄1</span><input value={a} onChange={e=>setA(e.target.value)} placeholder="入力してください"/></label>
   <label><span>入力欄2</span><input value={b} onChange={e=>setB(e.target.value)} placeholder="入力してください"/></label>
   <button disabled={busy}>{busy?"送信中…":"送信"}</button><p className="message">{msg}</p>
  </form><a className="admin-link" href="/admin">送信内容を見る →</a></main>;
}

function Admin(){
 const {user,signOut}=useAuthenticator(ctx=>[ctx.user]); const [rows,setRows]=useState([]);
 async function load(){const {data}=await client.models.Submission.list();setRows(data||[])}
 useEffect(()=>{load()},[]);
 async function remove(id){if(!confirm("このデータを削除しますか？"))return;await client.models.Submission.delete({id});load()}
 return <main className="page wide"><a className="back" href="/">← 入力画面</a>
  <section className="hero compact"><p className="eyebrow">SUBMISSIONS</p><h1>送信された内容</h1>
  <p className="lead">管理者のみ閲覧できます。</p></section>
  <div className="adminbar"><span>{user?.signInDetails?.loginId||""}</span><button onClick={signOut}>ログアウト</button></div>
  <div className="submissions">{!rows.length&&<div className="empty">まだ送信されたデータはありません。</div>}
   {rows.map(r=><article className="submission" key={r.id}><div className="submission-top"><span>#{r.id.slice(0,8)}</span>
    <time>{r.createdAt?new Date(r.createdAt).toLocaleString("ja-JP"):""}</time></div>
    <div className="values"><div><small>入力欄1</small><strong>{r.field1}</strong></div>
    <div><small>入力欄2</small><strong>{r.field2}</strong></div></div>
    <button className="delete" onClick={()=>remove(r.id)}>削除</button></article>)}
  </div></main>;
}
function App(){return location.pathname==="/admin"?<Authenticator><Admin/></Authenticator>:<FormPage/>}
createRoot(document.getElementById("root")).render(<App/>);